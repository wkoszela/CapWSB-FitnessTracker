# LABORATORIUM 05
Termin upływa na 7 dni po rozpoczęciu laboratorium.
## Kontynuacja laboratorium, zakończenie przedmiotu - wystawienie ocen.