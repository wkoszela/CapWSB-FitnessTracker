@NonNullByDefault
package com.capgemini.wsb.fitnesstracker.statistics.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;