package com.capgemini.wsb.fitnesstracker.training.api;

public interface TrainingService {
}
