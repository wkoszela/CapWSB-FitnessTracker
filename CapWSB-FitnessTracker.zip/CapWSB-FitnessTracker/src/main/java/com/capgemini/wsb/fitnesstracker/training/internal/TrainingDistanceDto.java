package com.capgemini.wsb.fitnesstracker.training.internal;

import jakarta.annotation.Nullable;

public record TrainingDistanceDto(@Nullable Long id,
                                  double distance){

}
