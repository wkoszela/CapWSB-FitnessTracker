package com.capgemini.wsb.fitnesstracker.statistics.api;

public interface StatisticService {

    Statistics addStatistics(Statistics statistics);
}
